﻿using SoftUni.Data;
using SoftUni.Models;
using System.Text;

namespace SoftUni
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            SoftUniContext dbContext = new SoftUniContext();

            Console.WriteLine(GetEmployee147(dbContext));
        }

        //Problem 3
        public static string GetEmployeesFullInformation(SoftUniContext context)
        {
            StringBuilder sb = new StringBuilder();

            var employees = context.Employees
                                   .Select(e => new
                                   {
                                       e.EmployeeId,
                                       e.FirstName,
                                       e.LastName,
                                       e.MiddleName,
                                       e.JobTitle,
                                       e.Salary
                                   })
                                   .OrderBy(e => e.EmployeeId)
                                   .ToArray();

            foreach (var employee in employees)
            {
                sb.AppendLine($"{employee.FirstName} {employee.LastName} {employee.MiddleName} {employee.JobTitle} {employee.Salary:F2}");
            }

            return sb.ToString().TrimEnd();
        }

        //Problem 4
        public static string GetEmployeesWithSalaryOver50000(SoftUniContext context)
        {
            StringBuilder sb = new StringBuilder();

            var employees = context.Employees
                                   .Select(e => new
                                   {
                                       e.FirstName,
                                       e.Salary
                                   })
                                   .Where(e => e.Salary > 50000)
                                   .OrderBy(e => e.FirstName)
                                   .ToArray();

            foreach (var employee in employees)
            {
                sb.AppendLine($"{employee.FirstName} - {employee.Salary:F2}");
            }

            return sb.ToString().TrimEnd();
        }

        //Problem 5
        public static string GetEmployeesFromResearchAndDevelopment(SoftUniContext context)
        {
            StringBuilder sb = new StringBuilder();

            var employees = context.Employees
                                   .Select(e => new
                                   {
                                       e.FirstName,
                                       e.Department.Name,
                                       e.Salary,
                                       e.LastName
                                   })
                                   .Where(e => e.Name == "Research and Development")
                                   .OrderBy(e => e.Salary)
                                   .ThenByDescending(e => e.FirstName)
                                   .ToArray();

            foreach (var employee in employees)
            {
                sb.AppendLine($"{employee.FirstName} {employee.LastName} from Research and Development - ${employee.Salary:F2}");
            }

            return sb.ToString().TrimEnd();
        }

        //Problem 6
        public static string AddNewAddressToEmployee(SoftUniContext context)
        {

            Address newAddress = new Address()
            {
                TownId = 4,
                AddressText = "Vitoshka 15"
            };

            Employee? employeeNakov = context.Employees.FirstOrDefault(e => e.LastName == "Nakov");

            employeeNakov!.Address = newAddress;

            context.SaveChanges();

            string[] employees = context.Employees
                                  .OrderByDescending(e => e.AddressId)
                                  .Take(10)
                                  .Select(e => e.Address!.AddressText)
                                  .ToArray();

            return string.Join(Environment.NewLine, employees);

        }

        //Problem 8
        public static string GetAddressesByTown(SoftUniContext context)
        {
            StringBuilder sb = new StringBuilder();

            var addresses = context.Addresses
                                   .OrderByDescending(a => a.Employees.Count)
                                   .ThenBy(t => t.Town!.Name)
                                   .ThenBy(a => a.AddressText)
                                   .Take(10)
                                   .Select(a => new
                                   {
                                       a.AddressText,
                                       TownName = a.Town!.Name,
                                       EmployeeCount = a.Employees.Count
                                   })
                                   .ToArray();

            foreach (var address in addresses)
            {
                sb.AppendLine($"{address.AddressText}, {address.TownName} - {address.EmployeeCount} employees");
            }

            return sb.ToString().TrimEnd();
        }

        //Problem 9
        public static string GetEmployee147(SoftUniContext context)
        {
            StringBuilder sb = new StringBuilder();

            var employee147Info = context.Employees
                                         .Where(e => e.EmployeeId == 147)
                                         .Select(e => new
                                         {
                                             FirstName = e.FirstName,
                                             LastName = e.LastName,
                                             JobTitle = e.JobTitle,
                                             Projects = e.EmployeesProjects
                                                         .Select(p => new
                                                         {
                                                             ProjectName = p.Project!.Name
                                                         })
                                                         .OrderBy(p => p.ProjectName)
                                                         .ToArray()
                                         })
                                         .FirstOrDefault();

            sb.AppendLine($"{employee147Info!.FirstName} {employee147Info.LastName} - {employee147Info.JobTitle}");

            foreach (var project in employee147Info.Projects)
            {
                sb.AppendLine(project.ProjectName);
            }

            return sb.ToString().TrimEnd();
        }
    }
}