﻿namespace P01_StudentSystem.Data.Common;

public static class DbConfig
{
    public const string ConnectionString =
        @"Server=DESKTOP-2D5095T\SQLEXPRESS;Database=StudentSystem;Integrated Security=True;Encrypt=False";
}