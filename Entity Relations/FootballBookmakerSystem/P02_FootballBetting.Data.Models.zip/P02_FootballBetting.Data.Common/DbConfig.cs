﻿namespace P02_FootballBetting.Data.Common;

public static class DbConfig
{
    public const string ConnectionString =
        @"Server=DESKTOP-2D5095T\SQLEXPRESS;Database=FootballBookmakerSystem;Integrated Security=True;Encrypt=False;";
}
